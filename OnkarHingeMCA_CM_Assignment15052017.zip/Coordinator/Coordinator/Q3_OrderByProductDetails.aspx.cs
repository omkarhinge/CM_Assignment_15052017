﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace Coordinator
{
    public partial class Q3_OrderByProductDetails : System.Web.UI.Page
    {
        
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\InsertUpdateDeleteSearch\Coordinator\Coordinator\App_Data\LearningManagementSystem.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            bindgrid();


        }

        public void bindgrid()
        {
            con.Open();
            string query = "select Orders.OrderId, Orders.OrderDate,Orders.CustomerID,OrderItem.productId,"
                   + " Products.ProductName, OrderItem.unitPrice,OrderItem.Quantity from Orders"
                   + " inner join OrderItem on Orders.OrderId = OrderItem.OrderId "
                   + " inner join Products on Products.ProductId = OrderItem.ProductId";

            SqlCommand gcmd = new SqlCommand(query, con);
            SqlDataAdapter ged = new SqlDataAdapter(gcmd);
            DataTable dt = new DataTable();
            ged.Fill(dt);
            GridView_Orders.DataSource = dt;
            GridView_Orders.DataBind();
            con.Close();

        }
    }
}