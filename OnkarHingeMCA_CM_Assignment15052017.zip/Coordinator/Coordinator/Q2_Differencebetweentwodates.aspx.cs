﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Coordinator
{
    public partial class Differencebetweentwodates : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtDateOne.Text = Calendar1.SelectedDate.ToShortDateString();
            
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            txtDateTwo.Text = Calendar2.SelectedDate.ToShortDateString();

        }

        protected void btnDateDifference_Click(object sender, EventArgs e)
        {
            DateTime d1 = Convert.ToDateTime(txtDateOne.Text);
            DateTime d2 = Convert.ToDateTime(txtDateTwo.Text);
            int noofyears = (d2.Year - d1.Year) * 365;
            int noofmonths = (d2.Month - d1.Month) * 30;
            int noofdays = (d2.Day - d1.Day);
            int totalapproxdiffday = noofdays + noofmonths + noofyears;
            lblDateDifference.Text = "Approx Days Diff=" + totalapproxdiffday.ToString();
        }
    }
}