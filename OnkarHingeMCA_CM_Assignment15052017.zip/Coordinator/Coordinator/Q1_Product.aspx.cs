﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Coordinator
{

    public class product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public int Price { get; set; }
        public string ProductDescription { get; set; }
    }

    public partial class Product : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\InsertUpdateDeleteSearch\Coordinator\Coordinator\App_Data\LearningManagementSystem.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            bindgrid();


        }

        protected void btnSubmitt_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Insert into Product values ('"+txtProductName.Text + "','" + txtCategory.Text + "','" + txtQuantity.Text + "','" + txtPrice.Text + "','" + txtProductDescription.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            lblMessageDisplay.Text = "Added";
            bindgrid();
        }

        protected void BtnReset_Click(object sender, EventArgs e)
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtCategory.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
            txtProductDescription.Text = "";
        }

        protected void GridViewProduct_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void GridViewProduct_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridViewProduct.EditIndex = -1;
            bindgrid();
        }

        protected void GridViewProduct_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int pno = 0;
            pno = Convert.ToInt32(GridViewProduct.Rows[e.RowIndex].Cells[0].Text);
            DeleteProduct(pno);
            bindgrid();
        }

        protected void GridViewProduct_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            product p = new product();
             p.ProductId = Convert.ToInt32(GridViewProduct.Rows[e.RowIndex].Cells[0].Text);
            p.ProductName = GridViewProduct.Rows[e.RowIndex].Cells[1].Text;
            p.Category = GridViewProduct.Rows[e.RowIndex].Cells[2].Text;
            p.Quantity = Convert.ToInt32(GridViewProduct.Rows[e.RowIndex].Cells[3].Text);
            p.Price = Convert.ToInt32(GridViewProduct.Rows[e.RowIndex].Cells[4].Text);
            p.ProductDescription = GridViewProduct.Rows[e.RowIndex].Cells[4].Text;
                
             UpdateProduct(p);
            bindgrid();
        }

        public void UpdateProduct(product p)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Update Product set ProductName="+ p.ProductName + ",Category=" + p.Category + "',Quantity='" + p.Quantity + "',Price='" + p.Price + "',ProductDescription='" + p.ProductDescription + "'where ProductId=" +p.ProductId;
            cmd.ExecuteNonQuery();
            con.Close();
            lblMessageDisplay.Text = "Updated";
            bindgrid();

        }
        // Delete 

        public void DeleteProduct(int ProductId)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            string productId = Convert.ToString(ProductId);
            cmd.CommandText = "Delete from Product where ProductId=" + productId;
            cmd.ExecuteNonQuery();
            con.Close();
            lblMessageDisplay.Text = "Deleted";

        }

        public void bindgrid()
        {
            con.Open();
            SqlCommand gcmd = new SqlCommand("select * from Product", con);
            SqlDataAdapter ged = new SqlDataAdapter(gcmd);
            DataTable dt = new DataTable();
            ged.Fill(dt);
            GridViewProduct.DataSource = dt;
            GridViewProduct.DataBind();
            con.Close();

        }

       
    }
}